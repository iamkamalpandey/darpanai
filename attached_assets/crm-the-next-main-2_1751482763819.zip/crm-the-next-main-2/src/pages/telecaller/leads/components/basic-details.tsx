import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import Select from "react-select";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { leadValidationSchema } from "@/schemas/lead-schema";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Calendar, MessageSquare } from "lucide-react";

const BasicDetails = ({
  initialValues,
  handleSubmit,
  formikProps,
  lead,
}: {
  initialValues: any;
  handleSubmit: any;
  formikProps: any;
  lead: any;
}) => {
  const { values, handleChange, setFieldValue, touched, errors } = formikProps;
  //@ts-ignore
  const { setLoading } = useAuth();
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    fetchCountries();
  }, []);

  const fetchCountries = async () => {
    setLoading(true);
    try {
      const response = await api.get("/countries");
      if (!response) throw new Error("Network response was not ok");
      const countryOptions = response.data.data.map((country: any) => ({
        value: country.id,
        label: country.name,
      }));
      setCountries(countryOptions);
    } catch (err) {
      console.error(err);
      // Handle error appropriately
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Card className="border-none mt-5 shadow-none">
        <CardContent className="gap-2.5 grid grid-cols-2 items-start">
          <div className="col-span-2">
            <Label
              htmlFor="profile_status"
              className="text-lg font-semibold text-gray-700"
            >
              Profile Status
            </Label>
            <div
              role="group"
              aria-labelledby="profile_status"
              className="flex gap-4 mt-2"
            >
              {/* Complete Option */}
              <div className="relative flex items-center">
                <Field
                  id="complete"
                  type="radio"
                  name="profile_status"
                  value="complete"
                  checked={values.profile_status === "complete"}
                  onChange={handleChange}
                  className="sr-only" // Hide the default radio button
                />
                <label
                  htmlFor="complete"
                  className="flex items-center cursor-pointer text-sm font-medium text-gray-900"
                >
                  <span className="flex items-center justify-center w-4 h-4 border border-gray-300 rounded-full">
                    {values.profile_status === "complete" && (
                      <span className="block w-2 h-2 bg-blue-600 rounded-full"></span> // Tick indicator
                    )}
                  </span>
                  <span className="ml-2">Complete</span>
                </label>
              </div>

              {/* Incomplete Option */}
              <div className="relative flex items-center">
                <Field
                  id="incomplete"
                  type="radio"
                  name="profile_status"
                  value="incomplete"
                  checked={values.profile_status === "incomplete"}
                  onChange={handleChange}
                  className="sr-only" // Hide the default radio button
                />
                <label
                  htmlFor="incomplete"
                  className="flex items-center cursor-pointer text-sm font-medium text-gray-900"
                >
                  <span className="flex items-center justify-center w-4 h-4 border border-gray-300 rounded-full">
                    {values.profile_status === "incomplete" && (
                      <span className="block w-2 h-2 bg-pink-600 rounded-full"></span> // Tick indicator
                    )}
                  </span>
                  <span className="ml-2">Incomplete</span>
                </label>
              </div>
            </div>
          </div>

          <div className="">
            <Label htmlFor="name">First Name</Label>
            <Input
              id="first_name"
              name="first_name"
              value={values?.first_name}
              onChange={handleChange}
            />
            {touched.first_name && errors.first_name ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.first_name}
              </div>
            ) : null}
          </div>
          <div className="">
            <Label htmlFor="last_name">Last Name</Label>
            <Input
              id="last_name"
              name="last_name"
              value={values?.last_name}
              onChange={handleChange}
            />
            {touched.last_name && errors.last_name ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.last_name}
              </div>
            ) : null}
          </div>
          <div className="">
            <Label htmlFor="gender">Gender</Label>
            <select
              id="gender"
              name="gender"
              value={values?.gender}
              onChange={handleChange}
              className="block w-full mt-1 py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            >
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="flex flex-col gap-1.5 w-full">
            <Label htmlFor="">Date of Birth</Label>
            <DatePicker
              selected={values?.dob}
              onChange={(date: Date) => setFieldValue("dob", date)}
              className="block w-full mt-1 py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              dateFormat="MM/dd/yyyy"
              peekNextMonth
              showMonthDropdown
              showYearDropdown
              dropdownMode="select"
            />
          </div>

          <div className="">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              name="email"
              value={values?.email}
              onChange={handleChange}
            />
            {touched.email && errors.email ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.email}
              </div>
            ) : null}
          </div>
          <div className="">
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone_number"
              name="phone_number"
              value={values?.phone_number}
              onChange={handleChange}
            />
            {touched.phone_number && errors.phone_number ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.phone_number}
              </div>
            ) : null}
          </div>
          <div className="">
            <Label htmlFor="phone">Secondary Phone Number</Label>
            <Input
              id="secondary_number"
              name="secondary_number"
              value={values?.secondary_number}
              onChange={handleChange}
            />
            {touched.secondary_number && errors.secondary_number ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.secondary_number}
              </div>
            ) : null}
          </div>
          <div className="">
            <Label htmlFor="interested_countries">Interested Countries</Label>
            <Select
              id="interested_countries"
              name="interested_countries"
              value={values.interested_countries}
              onChange={(value) => setFieldValue("interested_countries", value)}
              options={countries}
              isMulti
            />
          </div>
          <div className="">
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              name="city"
              value={values?.city}
              onChange={handleChange}
            />
            {touched.city && errors.city ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.city}
              </div>
            ) : null}
          </div>
          <div className="">
            <Label htmlFor="interested_course">Interested Course</Label>
            <Input
              id="interested_course"
              name="interested_course"
              value={values?.interested_course}
              onChange={handleChange}
            />
            {touched.interested_course && errors.interested_course ? (
              <div style={{ color: "red", marginTop: "0.5rem" }}>
                {errors.interested_course}
              </div>
            ) : null}
          </div>

          <div className="col-span-2">
            <Label htmlFor="remarks">Remarks</Label>
            <Textarea
              id="remark"
              name="remark"
              value={values?.remark}
              onChange={handleChange}
            />
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="link">Show Remarks</Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>All Remarks</SheetTitle>
                  <SheetDescription>All remarks listed below</SheetDescription>
                </SheetHeader>
                <div className="grid gap-4 py-4">
                  {values?.remarks.map((item: any) => {
                    const formattedDate = new Date(
                      item.createdAt
                    ).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                      weekday: "long",
                    });
                    return (
                      <div className="bg-white shadow-md rounded-lg p-4 flex flex-col justify-between leading-normal">
                        <div className="mb-2">
                          <div className="text-gray-900 font-bold text-xl mb-2 flex items-center">
                            <MessageSquare className="mr-2" size={20} /> Remark
                          </div>
                          <p className="text-gray-700 text-base">
                            {item.content}
                          </p>
                        </div>
                        <div className="flex items-center justify-end">
                          <Calendar className="mr-1" size={16} />
                          <span className="text-sm text-gray-600">
                            {formattedDate}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <SheetFooter>
                  <SheetClose asChild></SheetClose>
                </SheetFooter>
              </SheetContent>
            </Sheet>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="bg-green-600 hover:bg-green-700">
            Save Changes
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default BasicDetails;
