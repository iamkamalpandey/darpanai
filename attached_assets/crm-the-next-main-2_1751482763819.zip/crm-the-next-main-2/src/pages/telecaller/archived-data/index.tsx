import React, { useEffect, useState } from "react";
import Layout from "../layout";

import Header from "@/components/shared/Header/Header";

import api from "@/services/api";
import { Lead } from "@/types/api-types";

import CounsellorArchiveTable from "@/components/common/counsellor/CounsellorArchiveTable";
const index = () => {
  const [data, setData] = useState<Lead[]>([]);
  useEffect(() => {
    api.get("archive-user").then((response) => {
      setData(response.data.data);
    });
  }, []);
  return (
    <Layout>
      <Header title="Archived Leads" />
      <div className="p-2.5 flex flex-col gap-2.5">
        <CounsellorArchiveTable people={data} />
      </div>
    </Layout>
  );
};

export default index;
